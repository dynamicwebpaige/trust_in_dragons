
This relational algebra interpreter was originally distributed
with gadfly.  I'm adding it back after modifying it to work with
the new conventions.
